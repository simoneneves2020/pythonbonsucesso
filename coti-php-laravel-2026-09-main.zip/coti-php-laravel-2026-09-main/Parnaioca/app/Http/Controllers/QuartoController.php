<?php

namespace App\Http\Controllers;

use App\Models\Quarto;

use Illuminate\Http\Request;
use App\Http\Requests\StoreQuartoRequest;
use App\Http\Requests\UpdateQuartoRequest;

use Illuminate\Support\Facades\Mail;
use App\Mail\ReservaCriada;


class QuartoController extends Controller
{
    public function index()
    {
        flash('Welcome Aboard!', 'success');

        Mail::to('cliente@parnaioca.com.br')
            ->send(new ReservaCriada());

        return view('quartos',
            [
                "quartos" => Quarto::all(),
            ]
        );
    }

    public function show(Quarto $quarto)
    {
        return view('quarto',
            [
                "quarto" => $quarto
            ]
        );
    }

    public function create()
    {
        // regra de negócio
        return view('create');
    }

    public function store(StoreQuartoRequest $request)
    {
        // SEM FILLABLE NO QUARTO MODEL
        // $quarto = new Quarto();
        // $quarto->nome = $request->validated()->nome;
        // $quarto->tipo = $request->validated()->tipo;
        // $quarto->valorDiaria = $request->validated()->valorDiaria;
        // $quarto->disponivel = $request->validated()->disponivel;
        // $quarto->save();

        // COM FILLABLE NO QUARTO MODEL
        $quarto = Quarto::create($request->validated());

        if ($request->hasFile('imagem')) {
            $caminho = $request
                ->file('imagem')
                ->store('quartos', 'public');

            // $quarto->imagem = $caminho;

            // $quarto->save();
        }

        return redirect()->route('quartos.index')->with('success','Quarto cadastrado com sucesso!!');
    }

    public function edit(Quarto $quarto)
    {
        return view('edit', [
            'quarto' => $quarto
        ]);
    }

    public function update(Quarto $quarto, UpdateQuartoRequest $request)
    {
        $quarto->update($request->all());

        return redirect()->route('quartos.index')->with('success','Quarto atualizado com sucesso!!');
    }

    public function destroy(Quarto $quarto)
    {
        $quarto->delete();

        return redirect()->route('quartos.index')->with('success','Quarto removido com sucesso!!');
    }
}
