# Formação Java WebDeveloper – COTI Informática

Quatro APIs REST em **Java 21 + Spring Boot 3** que fiz durante a formação Java WebDeveloper da COTI Informática. Cada pasta é um projeto Maven independente, com seu próprio `docker-compose.yml`.

| API | Porta | Banco | Destaques |
|---|---|---|---|
| [`apiClientes`](./apiClientes) | 8081 | MySQL | CRUD de clientes, dashboard por tipo, filtro JWT, Swagger |
| [`apiUsuarios`](./apiUsuarios) | 8082 | PostgreSQL | Cadastro e autenticação, senha SHA-256, token JWT, perfis e permissões |
| [`apiProduto`](./apiProduto) | 8084 | MongoDB | Camadas application / domain / infrastructure, validação, publica eventos no RabbitMQ |
| [`apiHistoricos`](./apiHistoricos) | 8085 | MongoDB | Consome os eventos de produto do RabbitMQ e grava o histórico de alterações |

## Arquitetura

```mermaid
flowchart LR
  U[apiUsuarios] -- JWT --> C[apiClientes]
  P[apiProduto] -- evento --> R[(RabbitMQ)]
  R --> H[apiHistoricos]
  C --- MY[(MySQL)]
  U --- PG[(PostgreSQL)]
  P --- M[(MongoDB)]
  H --- M
```

## Como rodar

Pré-requisitos: Java 21, Docker e Docker Compose.

```bash
cd apiProduto          # ou qualquer outra pasta
docker compose up -d   # sobe banco / RabbitMQ
./mvnw spring-boot:run
```

A documentação Swagger fica em `http://localhost:<porta>/swagger-ui.html`.

## O que pratiquei

- APIs REST com Spring Web, Spring Data JPA e Spring Data MongoDB
- Autenticação com JWT e filtros de segurança
- Mensageria assíncrona com RabbitMQ (produtor e consumidor)
- Validação com Bean Validation e tratamento global de exceções
- Containers com Docker Compose
