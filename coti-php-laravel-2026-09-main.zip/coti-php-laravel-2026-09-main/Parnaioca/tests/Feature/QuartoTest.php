<?php

use Illuminate\Foundation\Testing\RefreshDatabase;

uses(RefreshDatabase::class);

test('deve_acessar_quartos', function () {
    $response = $this->get('/quartos');

    $response->assertStatus(302);
});
